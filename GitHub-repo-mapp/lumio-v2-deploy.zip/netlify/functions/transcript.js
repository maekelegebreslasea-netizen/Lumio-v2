// netlify/functions/transcript.js
// Fetches YouTube video transcript for Lumio AI teaching

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  try {
    const { videoId } = JSON.parse(event.body || "{}");
    if (!videoId) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing videoId" }) };
    }

    // Step 1: Fetch the YouTube page to get the caption track URL
    const pageRes = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; Lumio/1.0)",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });

    if (!pageRes.ok) {
      return { statusCode: 502, headers, body: JSON.stringify({ error: "Could not fetch video page" }) };
    }

    const html = await pageRes.text();

    // Step 2: Extract ytInitialPlayerResponse
    const playerMatch = html.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\})\s*;/s);
    if (!playerMatch) {
      // Fallback: try timedtext API directly
      const fallback = await tryTimedText(videoId);
      if (fallback) return { statusCode: 200, headers, body: JSON.stringify({ transcript: fallback }) };
      return { statusCode: 404, headers, body: JSON.stringify({ error: "No transcript found" }) };
    }

    let playerData;
    try {
      playerData = JSON.parse(playerMatch[1]);
    } catch {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Could not parse player data" }) };
    }

    // Step 3: Find caption tracks
    const captions = playerData?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    if (!captions || captions.length === 0) {
      // Try timedtext fallback
      const fallback = await tryTimedText(videoId);
      if (fallback) return { statusCode: 200, headers, body: JSON.stringify({ transcript: fallback }) };
      return { statusCode: 404, headers, body: JSON.stringify({ error: "No captions available for this video" }) };
    }

    // Prefer English, otherwise first available
    const track =
      captions.find(t => t.languageCode === "en") ||
      captions.find(t => t.languageCode === "en-US") ||
      captions[0];

    const captionUrl = track.baseUrl;

    // Step 4: Fetch the caption track
    const captionRes = await fetch(captionUrl + "&fmt=json3");
    if (!captionRes.ok) {
      // Try XML format
      const xmlRes = await fetch(captionUrl);
      if (!xmlRes.ok) return { statusCode: 502, headers, body: JSON.stringify({ error: "Could not fetch captions" }) };
      const xml = await xmlRes.text();
      const transcript = parseXMLCaptions(xml);
      return { statusCode: 200, headers, body: JSON.stringify({ transcript }) };
    }

    const captionData = await captionRes.json();

    // Step 5: Parse JSON3 format
    const transcript = captionData.events
      ? captionData.events
          .filter(e => e.segs)
          .map(e => e.segs.map(s => s.utf8 || "").join(""))
          .join(" ")
          .replace(/\s+/g, " ")
          .replace(/\[.*?\]/g, "") // Remove [Music], [Applause] etc
          .trim()
      : "";

    if (!transcript) {
      return { statusCode: 404, headers, body: JSON.stringify({ error: "Empty transcript" }) };
    }

    // Limit to ~10,000 chars for Lumio AI
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ transcript: transcript.slice(0, 10000) }),
    };

  } catch (err) {
    console.error("Transcript error:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Internal error: " + err.message }),
    };
  }
};

// Fallback: try YouTube timedtext API
async function tryTimedText(videoId) {
  try {
    const langs = ["en", "en-US", "en-GB"];
    for (const lang of langs) {
      const res = await fetch(
        `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${lang}&fmt=json3`
      );
      if (!res.ok) continue;
      const data = await res.json();
      if (data.events) {
        const text = data.events
          .filter(e => e.segs)
          .map(e => e.segs.map(s => s.utf8 || "").join(""))
          .join(" ")
          .replace(/\s+/g, " ")
          .trim();
        if (text.length > 50) return text.slice(0, 10000);
      }
    }
  } catch {}
  return null;
}

// Parse XML caption format
function parseXMLCaptions(xml) {
  return xml
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 10000);
}
