# Lumio — Driftsättningsguide

## 1. Netlify Environment Variables (OBLIGATORISKT)

Gå till: Netlify Dashboard → Site Settings → Environment Variables → Add variable

| Variabel | Värde |
|---|---|
| `ANTHROPIC_API_KEY` | Din Anthropic API-nyckel (sk-ant-...) |
| `SUPABASE_URL` | https://jmsaceushtshgqulreyu.supabase.co |
| `SUPABASE_SERVICE_KEY` | Din Supabase service role key (från Supabase → Settings → API) |

## 2. Supabase — Skapa usage-tabell

Kör detta SQL i Supabase SQL Editor:

```sql
CREATE TABLE IF NOT EXISTS usage (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  count INTEGER NOT NULL DEFAULT 0,
  UNIQUE(user_id, date)
);

ALTER TABLE usage ENABLE ROW LEVEL SECURITY;

-- Bara service role kan läsa/skriva
CREATE POLICY "Service role only" ON usage
  USING (false)
  WITH CHECK (false);
```

## 3. Deploy

```bash
cd din-lumio-mapp
# Kopiera alla filer från ZIP hit
git add .
git commit -m "Lumio production — no API key required"
git push
```

## Fil-struktur
```
index.html
manifest.json
netlify.toml
netlify/
  functions/
    chat.js        ← AI-proxy (elever behöver ingen nyckel)
    transcript.js  ← YouTube-transkript
```

## Gratisplan: 50 meddelanden/dag per användare
## Betalplan: Stripe-integration (nästa sprint)
